<?php $__env->startSection('content'); ?>
<?php

use App\Models\Task;
$totaltask = count(Task::all());
$activetask = count(Task::all()->where('status','active'));

?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard - Update Task')); ?></div>

                <div class="card-body">
                
                    <div class="row">
                        <div class="col-md-3 bg-info p-2">
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-light w-100 mb-2">Home</a>
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-light w-100 mb-2">Add New User</a>
                            <a href="<?php echo e(route('addnewtask')); ?>" class="btn btn-light w-100 mb-2">Add New Task</a>
                            <a href="<?php echo e(route('managetasks')); ?>" class="btn btn-light w-100 mb-2">Manage Tasks</a>
                        </div>
                        <div class="col-md-1">&nbsp;</div>
                        <div class="col-md-8">
                        <div class="card-body">
                    <form method="POST" action="<?php echo e(route('updatetask')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label for="title" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Title')); ?></label>

                            <div class="col-md-6">
                            <input id="id" type="hidden" class="form-control <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id" value="<?php echo e($task->id); ?>" required autocomplete="title" autofocus>
                                <input id="title" type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" value="<?php echo e($task->title); ?>" required autocomplete="title" autofocus>

                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="row mb-3">
                            <label for="description" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-6">
                                <input id="description" type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" value="<?php echo e($task->description); ?>" required autocomplete="description" autofocus>

                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="status" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Status')); ?></label>

                            <div class="col-md-6">
                                <select name="status" class="form-control">
                                    <option value="pending"
                                    <?php if($task->status == 'pending'): ?>) selected <?php endif; ?>
                                    >Pending</option>
                                    <option value="active"
                                    <?php if($task->status == 'active'): ?>) selected <?php endif; ?>
                                    >Active</option>
                                    <option value="completed"
                                    <?php if($task->status == 'completed'): ?>) selected <?php endif; ?>
                                    >Complete</option>
                                </select>

                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Update Task')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\Project_Management_WebApp\resources\views/edit.blade.php ENDPATH**/ ?>